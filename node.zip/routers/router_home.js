var express = require('express');
var router = express.Router();
var TCommon = require('../templetes/common.js');
var MongoClient = require('mongodb').MongoClient;
var mongoUrl = "mongodb://localhost:27017/";

router.get('/', (req, res) => {
    var content = TCommon.full();

    res.send(content);
});

router.post('/api/all', (req, res) => {
    var startDate = new Date(req.body.startDate);
    var endDate = new Date(req.body.endDate);
    console.log(startDate);
    console.log(endDate);

    MongoClient.connect(mongoUrl, (err, db) => {
        if (err) throw err;
        var practiceDB = db.db("practice");

        practiceDB.collection("report").find({"date": {
            $gte: startDate,
            $lt: endDate}}).toArray((err, arr) => {
            if (err) throw err;
            console.log(arr);
            db.close();
            res.status(200).send(arr);
        });
    });
});

module.exports = router;
