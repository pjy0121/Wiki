var express = require('express');
var app = express();
var fs = require('fs');
var bodyParser = require('body-parser');

var RHome = require('./routers/router_home');

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.get('*', function(req, res, next){
    fs.readdir('./data', function(error, filelist){
        req.list = filelist;
        next();
    });
});

app.use('/', RHome);

app.use(function(req, res, next) {
    res.status(404).send('Sorry cant find that!');
});

app.use(function (err, req, res, next) {
    console.error(err.stack)
    res.status(500).send('Something broke!')
});

const port = 9001;
app.listen(port, function() {
    console.log('Connected on 9001 Port')
});
