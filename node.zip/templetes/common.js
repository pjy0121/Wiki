module.exports = {
    header: (header) => {
        return `
        <!DOCTYPE html>
        <header>
            ${header}
        </header>
        <html>`;
    },

    head: (title) => {
        return `
        <head>
            <title>${title}</title>

            <meta charset="utf-8">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" ></script>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        </head>`;
    },

    body: (body) => {
        return `
        <body>
            ${body}
        </body>
        </html>`;
    },

    footer: (footer) => {
        return `
        <footer>
            ${footer}
        </footer>
        </html>`;
    },

    full: () => {
        return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>Sample</title>

            <meta charset="utf-8">
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
            <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" ></script>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
            <script src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
            <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"/>
        </head>
        <body>
            <div class="col-md-5">
                <canvas id="myChart"></canvas>
            </div>
            <input type="text" name="daterange" value="09/05/2021 - 09/20/2021" />
        </body>
        </html>
        <script>
        $(function() {
            $('input[name="daterange"]').daterangepicker({
                opens: 'left'
            }, function(start, end, label) {
                var params = {
                    startDate: new Date(start),
                    endDate: new Date(end)
                };
                console.log(params);
                sendAjax('/api/all', params);
            });
        });

        var ctx = document.getElementById("myChart").getContext('2d');

        var newChart;
        function sendAjax(url, params)
        {
            $.ajax({
                url: url,
                dataType: 'json',
                type: "post",
                data: params,
                success: (jsonArray) => {
                    var dates = jsonArray.map((x) => {
                        return x.date.split('T')[0];
                    });
                    var counts = jsonArray.map((x) => x.count);

                    if (newChart) {
                        newChart.destroy();
                    }

                    newChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: dates,
                            datasets: [{
                                label: '# of Votes',
                                data: counts,
                                backgroundColor: [
                                    'rgba(255, 99, 132, 0.2)',
                                    'rgba(54, 162, 235, 0.2)',
                                    'rgba(255, 206, 86, 0.2)',
                                    'rgba(75, 192, 192, 0.2)',
                                    'rgba(153, 102, 255, 0.2)',
                                    'rgba(255, 159, 64, 0.2)'
                                ]
                            }]
                        }
                    });
                }
            });
        }
        </script>`;
    }
}
